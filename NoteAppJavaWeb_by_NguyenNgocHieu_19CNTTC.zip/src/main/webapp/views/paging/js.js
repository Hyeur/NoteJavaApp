document.querySelector('.close').addEventListener('click', function (){
   document.querySelector('.bg-view').style.display = none;
});
document.getElementById('close').addEventListener('click', function (){
   document.querySelector('.bg-view').style.display = flex;
});
