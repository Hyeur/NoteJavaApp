# NoteAppJavaWeb

Đây là một Java webapp ứng dụng quản lý ghi chú, em phát triển project này không giống với tài liệu SRS giữa kỳ nên mong cô thông cảm

website: https://noteapp23.herokuapp.com/

webapp có database lưu trên phpmyadmin, có phân quyền đăng nhập, thiết kế theo mô hình MVC chuẩn jsp servlet

